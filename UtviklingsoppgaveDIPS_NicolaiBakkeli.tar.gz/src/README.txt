Development Task requested by DIPS
Solution written by Nicolai Bakkeli 1.nov.2017
Email: nibakkeli@gmail.com

Notable files:
Src/Bank/Bank.cs            (Contains the code)
Src/Bank.Tests/Bank_should.cs    (Contains the test code)

Run Test:
In shell: $dotnet test
